close all
clear all
clc

%Reciever code
disp ('Receiver Started');
t=tcpip('10.1.2.150', 5000 ,'NetworkRole','server');

% Waiting for connection
disp('Waiting for connection');
fopen(t);

disp('Connection OK');

% Read data from the socket
for i=0:0.1:20
   
   DataReceived   =  fread(t,1);
   motor_id = str2double(char(DataReceived))
 
   DataReceived2 = fread (t,4);
   motor_velocity = str2double(char(DataReceived2))
end
   
%  sim('input_v.slx')