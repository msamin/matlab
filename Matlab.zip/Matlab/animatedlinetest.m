% h=animatedline;
% axis = ([0,4*pi,-1,1])
% 
% x=linspace(0,4*pi,1000);
% y=sin(x);
% 
% for k=1:length(x)
%     addpoints(h,x(k),y(k));
%     drawnow
%     
% end
fid = fopen('/home/muhammad-precibake/Desktop/cpp2matlab.dat');
if fid>0
  %  loop until end of file is reached
    while ~feof(fid)
        %---------------------
        data = fileread('/home/muhammad-precibake/Desktop/cpp2matlab.dat')
        line = fgetl(fid);
        cdata = textscan(line, '%d %d %s %d %s %d',1)
        %----------------------
        
        logdate= cdata{1};
    logtime= cdata{2};
    c= cdata{3};
    motor_id= cdata{4};
    
    
    e= cdata{5}
    
    motor_velocity= cdata{6}
    H=plot(motor_velocity);
    
    set(H, 'Color','red')



    end
end


    