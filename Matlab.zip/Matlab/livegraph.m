%x=linspace(0,20);
%y=sin(x);
%line('xData',x,'yData',y)



fileID=fopen('/home/muhammad-precibake/Desktop/datafile')
formatSpec='%f';
A=fscanf(fileID,formatSpec);

tline =fgetl(fileID);

while ~feof(fileID)
    
    disp(tline)
    
   
    tline =fgetl(fileID);
    
end

fclose (fileID);