%input_v


data = fileread('/home/muhammad-precibake/Desktop/cpp2matlab.dat')
cdata = textscan(data, '%d %d %s %d %s %d',1);

%a = cdata{1}
%motor_id= cdata{2}
%aa = cdata{3}


%motor_velocity= cdata{4}

%-------------------------------------------------------------------------------
% fid = fopen('myFileName.txt');
 %if fid>0
  %   loop until end of file is reached
   %  while ~feof(fid)
    %     read the current line
     %    line = fgetl(fid);
      %   extract data from the line
       %  plot the data
        % wait two seconds until continuing with next line
        % pause(2.0);
     %end
    % close the file
   %  fclose(fid);
% end
%-------------------------------------------------------------------------------


logdate= cdata{1}
logtime= cdata{2}
c= cdata{3}
motor_id= cdata{4}
e= cdata{5}
motor_velocity= cdata{6}

sim('input_v')


