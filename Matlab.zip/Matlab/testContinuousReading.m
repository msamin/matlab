


fid = textread('/home/muhammad-precibake/Desktop/cpp2matlab.txt')
fid2 = fopen('/home/muhammad-precibake/Desktop/cpp2matlab.txt')

a=fid(:,4);
plot(a);



if fid2>0
  %  loop until end of file is reached
    while ~feof(fid2)
        %---------------------
      %  data = fileread('/home/muhammad-precibake/Desktop/cpp2matlab.dat');
        line = fgetl(fid2)
     cdata = textscan(line, '%d %d %d %d',1)
        %----------------------
        
    %    logdate= cdata{1};
   % logtime= cdata{2};
  %  c= cdata{3}
 %   motor_id= cdata{4}
    
  
 
   % e= cdata{5};
    
   % motor_velocity= cdata{6};


  

        
        % read the current line
       %  line = fgetl(fid);
       %  extract data from the line
        % plot the data
        % wait two seconds until continuing with next line
    %  pause(2.0);
    end
   
    
    %---------------------------------------------------------
% M = dlmread('/home/muhammad-precibake/Desktop/cpp2matlab.dat')
        
    %---------------------------------------------------------

    
    % close the file
     fclose(fid2);
 end
%---